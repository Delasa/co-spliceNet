meme ../out2/TCONS_00015312/R1_TCONS_00015312.fasta -o ../out2/TCONS_00015312/meme_R1_TCONS_00015312 -dna -minw 4 -maxw 7 -maxsize 200000 -mod zoops -nmotifs 3   
meme ../out2/TCONS_00015312/R2_TCONS_00015312.fasta -o ../out2/TCONS_00015312/meme_R2_TCONS_00015312 -dna -minw 4 -maxw 7 -maxsize 200000 -mod zoops -nmotifs 3   
meme ../out2/TCONS_00015312/R3_TCONS_00015312.fasta -o ../out2/TCONS_00015312/meme_R3_TCONS_00015312 -dna -minw 4 -maxw 7 -maxsize 200000 -mod zoops -nmotifs 3   
meme ../out2/TCONS_00015312/R4_TCONS_00015312.fasta -o ../out2/TCONS_00015312/meme_R4_TCONS_00015312 -dna -minw 4 -maxw 7 -maxsize 200000 -mod zoops -nmotifs 3   
